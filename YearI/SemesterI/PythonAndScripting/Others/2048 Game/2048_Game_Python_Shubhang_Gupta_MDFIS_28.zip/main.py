import UI

def main():
    gameGrid = UI.Game2048()

if __name__ == "__main__":
    main()